document.addEventListener("DOMContentLoaded", function () {
    const userList = document.getElementById("userList");

    // Obtener usuarios y listarlos
    function cargarUsuarios() {
        fetch("http://127.0.0.1:5000/api/usuarios")
            .then(response => response.json())
            .then(data => {
                userList.innerHTML = "";
                data.forEach(user => {
                    const li = document.createElement("li");
                    li.textContent = `${user.id_usuario} - ${user.nombre} (${user.email})`;
                    userList.appendChild(li);
                });
            })
            .catch(error => console.error("Error al obtener los usuarios:", error));
    }

    // Crear un usuario
    document.getElementById("createUserForm").addEventListener("submit", function (event) {
        event.preventDefault();
        const userData = {
            nombre: document.getElementById("nombre").value,
            email: document.getElementById("email").value,
            telefono: document.getElementById("telefono").value,
            fecha_contratacion: document.getElementById("fecha_contratacion").value,
            dias_vacaciones_disponibles: document.getElementById("dias_vacaciones_disponibles").value,
            dias_acumulados_anterior: document.getElementById("dias_acumulados_anterior").value,
            id_rol: document.getElementById("id_rol").value
        };

        fetch("http://127.0.0.1:5000/api/usuarios", {
            method: "POST",
            headers: { "Content-Type": "application/json" },
            body: JSON.stringify(userData)
        })
            .then(response => response.json())
            .then(() => {
                alert("Usuario creado");
                cargarUsuarios();
            })
            .catch(error => console.error("Error al crear usuario:", error));
    });

    //editar un usuario
    window.editarUsuario = async function () {
        const id = document.getElementById("editId").value.trim();
        const nombre = document.getElementById("editNombre").value.trim();
        const email = document.getElementById("editEmail").value.trim();
        const telefono = document.getElementById("editTelefono").value.trim();
        const id_rol = document.getElementById("editIdRol").value.trim();
      
        if (!id) {
          alert("Por favor, ingresa el ID del usuario.");
          return;
        }
      
        if (!nombre || !email || !telefono || !id_rol) {
          alert("Por favor, completa todos los campos para editar el usuario.");
          return;
        }
      
        try {
          const response = await fetch(`http://127.0.0.1:5000/api/usuarios/${id}`, {
            method: "PUT",
            headers: { "Content-Type": "application/json" },
            body: JSON.stringify({
              nombre,
              email,
              telefono,
              id_rol: Number(id_rol),
            }),
          });
      
          const data = await response.json();
      
          if (!response.ok) {
            throw new Error(data.error || "Error al actualizar el usuario");
          }
      
          alert("Usuario actualizado correctamente");
          cargarUsuarios();
      
        } catch (error) {
          console.error("Error al editar usuario:", error);
          alert(`Error: ${error.message}`);
        }
      };
      
      

    // Eliminar un usuario
    window.eliminarUsuario = function () {
        const id = document.getElementById("deleteId").value;

        fetch(`http://127.0.0.1:5000/api/usuarios/${id}`, { method: "DELETE" })
            .then(response => response.json())
            .then(() => {
                alert("Usuario eliminado");
                cargarUsuarios();
            })
            .catch(error => console.error("Error al eliminar usuario:", error));
    };

    cargarUsuarios();
});
