function loginUser(event) {
  event.preventDefault();  // Prevenir el comportamiento predeterminado del formulario

  const login = document.getElementById("login").value;
  const password = document.getElementById("password").value;

  fetch("http://127.0.0.1:5000/api/usuarios")
    .then(response => response.json())
    .then(data => {
      const usuario = data.find(user => user.email === login);

      if (!usuario) {
        alert("Usuario no encontrado");
        return;
      }

      // Validación temporal usando teléfono como "contraseña"
      if (usuario.telefono !== password) {
        alert("Contraseña incorrecta");
        return;
      }

      // ✅ Guardar ID del usuario en localStorage
      localStorage.setItem("id_usuario", usuario.id_usuario);

      // Redirigir según rol (id_rol: 1 = admin)
      if (usuario.id_rol === 1) {
        window.location.href = "admin_inicio.html";
      } else {
        window.location.href = "inicio.html";
      }
    })
    .catch(error => console.error("Error al obtener los usuarios:", error));
}
