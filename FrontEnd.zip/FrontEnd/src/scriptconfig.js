const API_GET = 'http://127.0.0.1:5000/api/historial-vacaciones'; // GET requiere ID de usuario
const API_UPDATE = 'http://127.0.0.1:5000/api/historial-vacaciones'; // PUT con ID historial

function agregarMensaje(remitente, mensaje) {
  const chat = document.getElementById('chat-messages');
  const p = document.createElement('p');
  p.innerHTML = `<strong>${remitente}:</strong> ${mensaje}`;
  chat.appendChild(p);
  chat.scrollTop = chat.scrollHeight;
}

function procesarChat() {
  const input = document.getElementById('chat-input');
  const mensaje = input.value.trim();
  if (!mensaje) return;

  agregarMensaje("Admin", mensaje);
  input.value = "";
  agregarMensaje("IA", "Procesando...");

  fetch(`${API_UPDATE}/chat`, {
    method: 'POST',
    headers: {
      'Content-Type': 'application/json'
    },
    body: JSON.stringify({ mensaje })
  })
  .then(res => res.json())
  .then(data => {
    // Elimina "Procesando..."
    const chat = document.getElementById('chat-messages');
    chat.lastChild.remove();

    if(data.success === false){
      // Mostrar mensaje de rechazo claro
      agregarMensaje("IA", `❌ Rechazo: ${data.message}`);
    } else {
      agregarMensaje("IA", data.message || "Solicitud procesada correctamente.");
    }
  })
  .catch(err => {
    console.error(err);
    const chat = document.getElementById('chat-messages');
    chat.lastChild.remove();
    agregarMensaje("IA", "Ocurrió un error al procesar la solicitud.");
  });
}


fetch('http://127.0.0.1:5000/api/usuarios')
  .then(res => res.json())
  .then(usuarios => {
    const select = document.getElementById('selectUsuario');
    usuarios.forEach(usuario => {
      const option = document.createElement('option');
      option.value = usuario.id_usuario;
      option.textContent = usuario.nombre;
      select.appendChild(option);
    });
  });

  function cargarHistorialPorUsuario() {
    const id = document.getElementById('selectUsuario').value;
  
    if (!id) return;
  
    fetch(`${API_GET}/${id}`)
      .then(res => res.json())
      .then(data => {
        const tbody = document.getElementById('tbodySolicitudes');
        tbody.innerHTML = '';
  
        data.forEach(solicitud => {
          const fila = document.createElement('tr');
          fila.innerHTML = `
            <td>${solicitud.id_historial}</td>
            <td>${solicitud.nombre || solicitud.id_usuario}</td>
            <td>${solicitud.fecha_solicitud}</td>
            <td>${solicitud.dias_otorgados}</td>
            <td>${solicitud.estado_final}</td>
            <td>
              <select id="estado-${solicitud.id_historial}" onchange="toggleMotivoRechazo(${solicitud.id_historial})">
                <option value="pendiente" ${solicitud.estado_final === 'pendiente' ? 'selected' : ''}>pendiente</option>
                <option value="aprobada" ${solicitud.estado_final === 'aprobada' ? 'selected' : ''}>aprobada</option>
                <option value="rechazada" ${solicitud.estado_final === 'rechazada' ? 'selected' : ''}>rechazada</option>
                <option value="cancelada" ${solicitud.estado_final === 'cancelada' ? 'selected' : ''}>cancelada</option>
              </select>
              <br>
              <input type="text" id="motivo-${solicitud.id_historial}" placeholder="Motivo rechazo" 
                value="${solicitud.motivo_rechazo || ''}" 
                style="display: ${solicitud.estado_final === 'rechazada' ? 'block' : 'none'}; margin-top: 5px; width: 90%;">
            </td>
            <td>
              <label>Inicio:<br><input type="date" id="fecha_inicio-${solicitud.id_historial}" value="${solicitud.fecha_inicio_otorgada ? solicitud.fecha_inicio_otorgada.split('T')[0] : ''}"></label><br>
              <label>Fin:<br><input type="date" id="fecha_fin-${solicitud.id_historial}" value="${solicitud.fecha_fin_otorgada ? solicitud.fecha_fin_otorgada.split('T')[0] : ''}"></label>
            </td>
            <td><button onclick="actualizarEstado(${solicitud.id_historial}, ${solicitud.dias_otorgados})">Actualizar</button></td>
          `;
  
          tbody.appendChild(fila);
        });
      });
  }
  

  function actualizarEstado(id_historial, dias_otorgados) {
    const nuevoEstado = document.getElementById(`estado-${id_historial}`).value;
    const motivoRechazoInput = document.getElementById(`motivo-${id_historial}`);
    const fechaInicioInput = document.getElementById(`fecha_inicio-${id_historial}`);
    const fechaFinInput = document.getElementById(`fecha_fin-${id_historial}`);
  
    const motivo_rechazo = nuevoEstado === 'rechazada' ? motivoRechazoInput.value.trim() || 'No especificado' : null;
  
    const datos = {
      fecha_aprobacion: new Date().toISOString().split('T')[0], // Hoy
      fecha_inicio_otorgada: fechaInicioInput.value || null,
      fecha_fin_otorgada: fechaFinInput.value || null,
      estado_final: nuevoEstado,
      dias_otorgados,
      motivo_rechazo
    };
  
    fetch(`${API_UPDATE}/${id_historial}`, {
      method: 'PUT',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify(datos)
    })
    .then(res => res.json())
    .then(data => {
      alert(data.message);
      location.reload();
    })
    .catch(err => {
      console.error('Error al actualizar:', err);
      alert('Error al actualizar la solicitud.');
    });
  }
  


// Toggle menú
function toggleMenu () {
  const menu = document.getElementById('menuContainer');
  menu.style.display = menu.style.display === 'block' ? 'none' : 'block';
}

document.addEventListener('click', function(event) {
  const menu= document.getElementById('menuContainer');
  const button = document.querySelector('.menu-btn');
  if (!menu.contains(event.target) && !button.contains(event.target)) {
    menu.style.display='none';
  }
});

function toggleMotivoRechazo(id_historial) {
  const estadoSelect = document.getElementById(`estado-${id_historial}`);
  const motivoInput = document.getElementById(`motivo-${id_historial}`);
  
  if (estadoSelect.value === 'rechazada') {
    motivoInput.style.display = 'block';
  } else {
    motivoInput.style.display = 'none';
    motivoInput.value = ''; // Opcional: limpia el campo si no está rechazado
  }
}
