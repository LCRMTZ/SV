const API_URL = 'http://127.0.0.1:5000/api/historial-vacaciones';
// Obtener ID del usuario desde localStorage
const id_usuario = localStorage.getItem('id_usuario');

// Si no está logueado, redirige
if (!id_usuario) {
  alert("Debes iniciar sesión");
  window.location.href = "login.html";
}

// Mostrar historial automáticamente
window.onload = () => {
AOS.init();
  fetch(`${API_URL}/${id_usuario}`)
    .then(res => res.json())
    .then(data => {
      if (!data || data.length === 0) {
        document.getElementById('resultadoHistorial').textContent = "No hay historial disponible.";
        return;
      }

      // Crear tabla
      let html = '<table border="1" cellpadding="5" cellspacing="0" style="border-collapse: collapse; width: 100%;">';
      html += '<thead><tr>';
      // Asumiendo campos: id_historial, fecha_inicio, fecha_fin, dias_otorgados, estado_final, motivo_rechazo
      html += '<th>ID</th><th>Fecha Inicio</th><th>Fecha Fin</th><th>Días Otorgados</th><th>Estado</th><th>Motivo Rechazo</th>';
      html += '</tr></thead><tbody>';

      data.forEach(item => {
        html += '<tr>';
        html += `<td>${item.id_historial || ''}</td>`;
        html += `<td>${item.fecha_inicio_otorgada || item.fecha_inicio || ''}</td>`;
        html += `<td>${item.fecha_fin_otorgada || item.fecha_fin || ''}</td>`;
        html += `<td>${item.dias_otorgados || ''}</td>`;
        html += `<td>${item.estado_final || ''}</td>`;
        html += `<td>${item.motivo_rechazo || ''}</td>`;
        html += '</tr>';
      });

      html += '</tbody></table>';

      document.getElementById('resultadoHistorial').innerHTML = html;
    })
    .catch(err => {
      document.getElementById('resultadoHistorial').textContent = "Error al cargar historial";
      console.error(err);
    });
};

function crearSolicitud() {
  const fecha_solicitud = document.getElementById('crearFechaSolicitud').value;
  const dias_otorgados = parseInt(document.getElementById('crearDias').value);
  const estado_final = "pendiente";


 
  const data = {
    id_usuario: id_usuario, // esta debe estar definida globalmente
    fecha_solicitud,
    dias_otorgados,
    estado_final
  };

  console.log("Datos a enviar:", data); // para verificar

  fetch(API_URL, {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify(data)
  })
    .then(async res => {
      if (!res.ok) {
        const errText = await res.text();
        throw new Error(`Error ${res.status}: ${errText}`);
      }
      return res.json();
    })
    .then(alerta => {
      alert(alerta.message);
      location.reload();
    })
    .catch(err => {
      console.error("Error en la solicitud:", err);
      alert("Ocurrió un error. Revisa la consola.");
    });
}


function eliminarSolicitud() {
  const id = document.getElementById('deleteIdHistorial').value;

  fetch(`${API_URL}/${id}`, { method: 'DELETE' })
    .then(res => res.json())
    .then(alerta => {
      alert(alerta.message);
      location.reload();
    });
}
